'''
Part 5

Obstacles + multiple robots

This part is a synthesis of Parts 3-4, implemented as follows:

The warehouse is divided into n sections {n: number of robots}

Each robot is responsible for performing tasks within the defined borders of their section





'''